﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;
using WebTest.Models;

namespace WebTest
{
    public partial class Signup : System.Web.UI.Page
    {

        protected void RegisterUser(object sender, EventArgs e)
        {
            var User = new User();

            User.UserName = txtUsername.Text.Trim();
            User.Password = txtPassword.Text.Trim();
            User.Email = txtEmail.Text.Trim();


            int userId = 0;
            string constr = ConfigurationManager.ConnectionStrings["WebFormConnectionString"].ConnectionString;
            using (SqlConnection con = new SqlConnection(constr))
            {
                using (SqlCommand cmd = new SqlCommand("Insert_User"))
                {
                    using (SqlDataAdapter sda = new SqlDataAdapter())
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@Username", User.UserName);//txtUsername.Text.Trim());
                        cmd.Parameters.AddWithValue("@Password", User.Password);//txtPassword.Text.Trim());
                        cmd.Parameters.AddWithValue("@Email", User.Email);//txtEmail.Text.Trim());
                        cmd.Connection = con;
                        con.Open();
                        userId = Convert.ToInt32(cmd.ExecuteScalar());
                        con.Close();
                    }
                }
                string message = string.Empty;
                switch (userId)
                {
                    case -1:
                        message = "Username already exists.\\nPlease choose a different username.";
                        break;
                    case -2:
                        message = "Supplied email address has already been used.";
                        break;
                    default:
                        message = "Registration successful.\\nUser Id: " + userId.ToString();
                        break;
                }
                ClientScript.RegisterStartupScript(GetType(), "alert", "alert('" + message + "');", true);
            }
        }

    }
}
